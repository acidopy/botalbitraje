# Bot de Arbitraje para Railway (Integrado)

Este bot de Telegram se conecta a Bybit para simular oportunidades de arbitraje.

## Instrucciones

1. Subí este proyecto a un repositorio de GitHub
2. Conectalo a Railway: "New Project" > "Deploy from GitHub"
3. Railway ejecutará el bot 24/7 automáticamente

Ya está listo con el `.env` configurado. ¡No necesitas hacer nada más!
